#ifndef YIYUAN3_H
#define YIYUAN3_H
struct st 
{
	double x1,x2;
	int flag;
};

st solver3(const double a,const double b,const double c,st &yiyuan);


#endif

