#include<iostream>
#include "yiyuan.h"
#include "yiyuan2.h"
#include "yiyuan3.h"
#include "yiyuan4.h"

using namespace std;


int main()
{
	cout << "������a b c" << endl; 
	double a,b,c,x1,x2;
	double *p1=&x1,*p2=&x2;
	int flag;
	st yiyuan;
	cin >> a >> b >> c;
	solver(a,b,c,x1,x2,flag);
	display(x1,x2,flag);
	reset(x1,x2,flag);
	flag=solver(a,b,c,x1,x2);
	display(x1,x2,flag);
	reset(x1,x2,flag);
	yiyuan=solver3(a,b,c,yiyuan);
	display(yiyuan.x1,yiyuan.x2,yiyuan.flag);
	reset(yiyuan.x1,yiyuan.x2,yiyuan.flag);
	solver4(a,b,c,&x1,&x2,flag);
	display((*p1),(*p2),flag);
	reset((*p1),(*p2),flag);
	return 0;
}
	
	
