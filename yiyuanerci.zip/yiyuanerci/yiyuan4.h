#ifndef YIYUAN4_H
#define YIYUAN4_H

void solver4(const double a,const double b,const double c,double *p1,double *p2,int &flag);

#endif

