//yiyuan2.cpp
#include "yiyuan2.h"
#include<iostream>
#include<cmath>
int	solver(const double a,const double b,const double c,double &x1,double &x2)
{
	int flag;
	double d=b*b-4*a*c;
	
	if(d<0) return 0;
	d=sqrt(d);
	if(a>0)
	{
		x1=(-b-d)/(2*a);
		x2=(-b+d)/(2*a);
	}
	else 
	{
		x1=(-b+d)/(2*a);
		x2=(-b-d)/(2*a);
	}
	if(d>0)
		flag=2;
	else 
		flag=1;
	return flag;
}
