//yiyuan3.cpp
#include "yiyuan3.h"
#include<iostream>
#include<cmath>
using namespace std;

st solver3(const double a,const double b,const double c,st &yiyuan)
{
	double d=b*b-4*a*c;
	
	if(d<0)
	{
		yiyuan.flag=0;
		return yiyuan;
	}
	d=sqrt(d);
	if(a>0)
	{
		yiyuan.x1=(-b-d)/(2*a);
		yiyuan.x2=(-b+d)/(2*a);
	}
	else
	{
		yiyuan.x1=(-b+d)/(2*a);
		yiyuan.x2=(-b-d)/(2*a);
	}
	if(d>0)
		yiyuan.flag=2;
	else
		yiyuan.flag=1;
	   
		return yiyuan;
	
}

