//yiyuan.cpp
#include "yiyuan.h"
#include<iostream>
#include<cmath>
using namespace std;
void solver(const double a,const double b,const double c,double &x1,double &x2,int &flag)
{
	double d=b*b-4*a*c;
	if(d<0)
	{
		flag=0;
		return;
	}
	d=sqrt(d);
	if(a>0)
	{
		x1=(-b-d)/(2*a);
		x2=(-b+d)/(2*a);
	}
	else
	{
		x1=(-b+d)/(2*a);
		x2=(-b-d)/(2*a);
	}
	if(d>0)
		flag=2;
	else
		flag=1;
}

void display(const double x1,const double x2,int flag)
{
	switch(flag)
	{
	case 1: cout << "�÷������ظ���x1 = x2 = " << x1;break;
    case 2: cout << "�÷��̵ĸ�Ϊ: x1 = " << x1 << ", x2 = " <<x2;break;
    case 0: cout << "�÷�����ʵ����";break;
	}
	cout << endl;
}

void reset(double &x1,double &x2,int &flag)
{
	x1=0,x2=0,flag=3;
}

