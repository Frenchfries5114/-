//yiyuan2.h
#ifndef YIYUAN2_H
#define YIYUAN2_H

int	solver(const double a,const double b,const double c,double &x1,double &x2);
	
#endif

