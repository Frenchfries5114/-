//yiyuan4.cpp
#include "yiyuan4.h"
#include<iostream>
#include<cmath>
using namespace std;

void solver4(const double a,const double b,const double c,double *p1,double *p2,int &flag)
{
	double d=b*b-4*a*c;
	if(d<0)
	{
		flag=0;
		return;
	}
	d=sqrt(d);
	if(a>0)
	{
		(*p1)=(-b-d)/(2*a);
		(*p2)=(-b+d)/(2*a);
	}
	else
	{
		(*p1)=(-b+d)/(2*a);
		(*p2)=(-b-d)/(2*a);
	}
	if(d>0)
		flag=2;
	else
		flag=1;
}
