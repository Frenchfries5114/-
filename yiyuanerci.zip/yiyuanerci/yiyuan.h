//yiyuan.h
#ifndef YIYUAN_H
#define YIYUAN_H

void solver(const double a,const double b,const double c,double &x1,double &x2,int &flag);
void display(const double x1,const double x2,int flag);
void reset(double &x1,double &x2,int &flag);

#endif

